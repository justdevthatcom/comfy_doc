package ru.gmdev.comfy_doc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComfyDocApplicationTests {

	@Test
	void contextLoads() {
	}

}
